using UnityEngine;

public class InputDriver : MonoBehaviour
{
    private void Update()
    {
        InputService.Update();
    }
}
